class MultiplayerClient {
  constructor() {
    this.ws = null;
    this.playerId = null;
    this.room = null;
    this.connected = false;
    this.listeners = new Set();
    this.pingTimer = null;
    this.connectPromise = null;
  }

  subscribe(fn) {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  emit(event) {
    for (const fn of this.listeners) {
      try {
        fn(event);
      } catch (err) {
        console.warn("Multiplayer listener error:", err);
      }
    }
  }

  getWsUrl() {
    const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
    return `${proto}//${window.location.host}/ws`;
  }

  connect() {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      return Promise.resolve();
    }
    if (this.connectPromise) {
      return this.connectPromise;
    }

    this.connectPromise = new Promise((resolve, reject) => {
      const ws = new WebSocket(this.getWsUrl());
      this.ws = ws;
      let settled = false;

      const timer = setTimeout(() => {
        if (!settled) {
          settled = true;
          this.connectPromise = null;
          reject(new Error("Không thể kết nối máy chủ phòng chơi."));
        }
      }, 8000);

      ws.onopen = () => {
        this.connected = true;
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          this.connectPromise = null;
          resolve();
        }
        this.startHeartbeat();
        this.emit({ type: "WS_OPEN" });
      };

      ws.onmessage = (ev) => {
        let msg;
        try {
          msg = JSON.parse(ev.data);
        } catch {
          return;
        }
        if (!msg || !msg.type) return;

        if (msg.type === "CONNECTED") {
          this.playerId = msg.playerId;
        } else if (msg.type === "ROOM_JOINED") {
          this.playerId = msg.playerId || this.playerId;
          this.room = msg.room;
        } else if (msg.type === "ROOM_UPDATE" || msg.type === "PLAYER_LEFT" || msg.type === "PLAYER_DOWNED" || msg.type === "WAVE_COMPLETED" || msg.type === "WAVE_STARTED" || msg.type === "MATCH_STARTED" || msg.type === "MATCH_OVER") {
          if (msg.room) {
            this.room = msg.room;
          }
        } else if (msg.type === "LEFT_ROOM") {
          this.room = null;
        }

        this.emit(msg);
      };

      ws.onerror = () => {
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          this.connectPromise = null;
          reject(new Error("Lỗi kết nối WebSocket."));
        }
      };

      ws.onclose = () => {
        this.connected = false;
        this.stopHeartbeat();
        if (!settled) {
          settled = true;
          clearTimeout(timer);
          this.connectPromise = null;
          reject(new Error("Kết nối máy chủ bị đóng."));
        }
        this.emit({ type: "WS_CLOSE" });
      };
    });

    return this.connectPromise;
  }

  startHeartbeat() {
    this.stopHeartbeat();
    this.pingTimer = setInterval(() => {
      this.send({ type: "PING" });
    }, 15000);
  }

  stopHeartbeat() {
    if (this.pingTimer) {
      clearInterval(this.pingTimer);
      this.pingTimer = null;
    }
  }

  isConnected() {
    return Boolean(this.connected && this.ws && this.ws.readyState === WebSocket.OPEN);
  }

  send(payload) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return false;
    this.ws.send(JSON.stringify(payload));
    return true;
  }

  async createRoom(playerName, heroId) {
    await this.connect();
    this.send({ type: "CREATE_ROOM", playerName, heroId });
  }

  async joinRoom(roomId, playerName, heroId) {
    await this.connect();
    this.send({ type: "JOIN_ROOM", roomId, playerName, heroId });
  }

  leaveRoom() {
    this.send({ type: "LEAVE_ROOM" });
    this.room = null;
  }

  selectHero(heroId) {
    this.send({ type: "SELECT_HERO", heroId });
  }

  setName(playerName) {
    this.send({ type: "SET_NAME", playerName });
  }

  toggleReady(ready) {
    this.send({ type: "TOGGLE_READY", ready });
  }

  startMatch() {
    this.send({ type: "START_MATCH" });
  }

  restartMatch() {
    this.send({ type: "RESTART_MATCH" });
  }

  setWaveReady(ready = true) {
    this.send({ type: "WAVE_READY", ready });
  }

  nextWave() {
    this.send({ type: "NEXT_WAVE" });
  }

  disconnect() {
    this.stopHeartbeat();
    if (this.ws) {
      try {
        this.ws.close();
      } catch {
      }
      this.ws = null;
    }
    this.room = null;
    this.connected = false;
  }
}

export const mpClient = new MultiplayerClient();
